'''
Created on Jul 25, 2012
@author: mlovci
@author: gabrielp

Refactored on June 29, 2020
@author: algaebrown

'''

############################################################
####### This files is for peak curve fitting ###############
############################################################